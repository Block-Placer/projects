import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { customAlphabet } from 'nanoid'

const nanoid = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 8)

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const category = searchParams.get('category')
  const difficulty = searchParams.get('difficulty')

  const quizzes = await prisma.quiz.findMany({
    where: {
      isPublic: true,
      ...(category ? { category } : {}),
      ...(difficulty ? { difficulty } : {}),
    },
    include: {
      _count: { select: { questions: true, attempts: true } },
      user: { select: { name: true } },
    },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json(quizzes)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json()
    const { title, description, category, difficulty, isPublic, timeLimit, questions } = body

    if (!title || !description || !questions || questions.length === 0) {
      return NextResponse.json({ error: 'Missing required fields.' }, { status: 400 })
    }

    if (questions.length < 1 || questions.length > 50) {
      return NextResponse.json({ error: 'A quiz must have 1-50 questions.' }, { status: 400 })
    }

    // Unique invite code
    let inviteCode = nanoid()
    while (await prisma.quiz.findUnique({ where: { inviteCode } })) {
      inviteCode = nanoid()
    }

    const quiz = await prisma.quiz.create({
      data: {
        title: title.trim(),
        description: description.trim(),
        category: category || 'General',
        difficulty: difficulty || 'Medium',
        isPublic: isPublic ?? true,
        timeLimit: timeLimit || 0,
        inviteCode,
        userId: session.user.id,
        questions: {
          create: questions.map((q: {
            text: string
            options: string[]
            correctAnswer: number
            explanation?: string
            order: number
          }) => ({
            text: q.text,
            options: JSON.stringify(q.options),
            correctAnswer: q.correctAnswer,
            explanation: q.explanation || '',
            order: q.order,
          })),
        },
      },
    })

    return NextResponse.json({ id: quiz.id, inviteCode: quiz.inviteCode })
  } catch (err) {
    console.error('Create quiz error:', err)
    return NextResponse.json({ error: 'Internal server error.' }, { status: 500 })
  }
}
