import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { score, total, timeTaken } = await req.json()

    if (score === undefined || total === undefined) {
      return NextResponse.json({ error: 'score and total are required.' }, { status: 400 })
    }

    const quiz = await prisma.quiz.findUnique({ where: { id: params.id } })
    if (!quiz) {
      return NextResponse.json({ error: 'Quiz not found.' }, { status: 404 })
    }

    const attempt = await prisma.quizAttempt.create({
      data: {
        userId: session.user.id,
        quizId: params.id,
        score,
        total,
        timeTaken: timeTaken || 0,
      },
    })

    return NextResponse.json({ id: attempt.id, score, total })
  } catch (err) {
    console.error('Attempt error:', err)
    return NextResponse.json({ error: 'Internal server error.' }, { status: 500 })
  }
}

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const attempts = await prisma.quizAttempt.findMany({
    where: { quizId: params.id },
    include: { user: { select: { name: true } } },
    orderBy: [{ score: 'desc' }, { timeTaken: 'asc' }],
    take: 20,
  })

  return NextResponse.json(attempts)
}
