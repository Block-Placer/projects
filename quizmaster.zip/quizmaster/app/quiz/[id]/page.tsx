import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { notFound } from 'next/navigation'
import Navbar from '@/components/Navbar'
import Link from 'next/link'
import QuizPlayer from './QuizPlayer'

const CATEGORY_ICONS: Record<string, string> = {
  Geography: '🌍', Science: '🔬', History: '📜',
  Arts: '🎨', Mathematics: '📐', General: '🧠',
  Technology: '💻', Sports: '⚽', Music: '🎵', Movies: '🎬',
}

export default async function QuizPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  const quiz = await prisma.quiz.findUnique({
    where: { id: params.id },
    include: {
      questions: { orderBy: { order: 'asc' } },
      user: { select: { name: true } },
      _count: { select: { attempts: true } },
    },
  })

  if (!quiz) notFound()

  const userAttempts = session
    ? await prisma.quizAttempt.findMany({
        where: { userId: session.user.id, quizId: quiz.id },
        orderBy: { completedAt: 'desc' },
        take: 5,
      })
    : []

  const bestScore = userAttempts.length > 0
    ? Math.max(...userAttempts.map(a => Math.round((a.score / a.total) * 100)))
    : null

  const icon = CATEGORY_ICONS[quiz.category] || '🧠'

  return (
    <div style={{ minHeight: '100vh', background: 'var(--ink)' }}>
      <Navbar />
      <main style={{ maxWidth: '800px', margin: '0 auto', padding: '2.5rem 1.5rem' }}>

        {/* Quiz header */}
        <div className="card" style={{ padding: '2rem', marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <div style={{
              width: '64px', height: '64px', flexShrink: 0,
              background: 'rgba(212,165,116,0.12)',
              borderRadius: '14px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '2rem',
            }}>
              {icon}
            </div>

            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '0.5rem' }}>
                <span className={`badge badge-${quiz.difficulty.toLowerCase()}`}>{quiz.difficulty}</span>
                <span className="badge" style={{ background: 'rgba(212,165,116,0.1)', color: 'var(--gold-light)', border: '1px solid rgba(212,165,116,0.2)' }}>
                  {quiz.category}
                </span>
              </div>
              <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.875rem', color: 'var(--parchment)', lineHeight: 1.2 }}>
                {quiz.title}
              </h1>
              <p style={{ color: 'var(--parchment-muted)', marginTop: '0.5rem', lineHeight: 1.6 }}>
                {quiz.description}
              </p>
            </div>
          </div>

          <div style={{
            display: 'flex', gap: '2rem', flexWrap: 'wrap',
            marginTop: '1.5rem', paddingTop: '1.5rem',
            borderTop: '1px solid var(--border)',
          }}>
            <Stat icon="❓" label="Questions" value={quiz.questions.length.toString()} />
            {quiz.timeLimit > 0 && <Stat icon="⏱" label="Time Limit" value={`${Math.floor(quiz.timeLimit / 60)}m`} />}
            <Stat icon="👥" label="Attempts" value={quiz._count.attempts.toString()} />
            <Stat icon="✍️" label="Created by" value={quiz.user.name} />
            {bestScore !== null && <Stat icon="🏆" label="Your best" value={`${bestScore}%`} />}
          </div>

          {/* Invite code */}
          <div style={{
            marginTop: '1rem',
            padding: '0.75rem 1rem',
            background: 'rgba(212,165,116,0.06)',
            border: '1px solid rgba(212,165,116,0.15)',
            borderRadius: '8px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <span style={{ fontSize: '0.85rem', color: 'var(--parchment-dim)' }}>
              Invite code: <span style={{ fontFamily: 'JetBrains Mono, monospace', color: 'var(--gold)', fontWeight: 500 }}>{quiz.inviteCode}</span>
            </span>
            <span style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)' }}>Share this to invite others →</span>
          </div>
        </div>

        {/* Quiz player */}
        {session ? (
          <QuizPlayer
            quiz={{
              id: quiz.id,
              title: quiz.title,
              timeLimit: quiz.timeLimit,
              questions: quiz.questions.map(q => ({
                id: q.id,
                text: q.text,
                options: JSON.parse(q.options),
                correctAnswer: q.correctAnswer,
                explanation: q.explanation,
              })),
            }}
          />
        ) : (
          <div className="card" style={{ padding: '2rem', textAlign: 'center' }}>
            <p style={{ color: 'var(--parchment-muted)', marginBottom: '1.25rem' }}>
              Sign in to take this quiz and track your progress.
            </p>
            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center' }}>
              <Link href={`/login?callbackUrl=/quiz/${quiz.id}`} className="btn-primary" style={{ textDecoration: 'none' }}>
                Sign in to play
              </Link>
              <Link href="/register" className="btn-secondary" style={{ textDecoration: 'none' }}>
                Create account
              </Link>
            </div>
          </div>
        )}

        {/* Previous attempts */}
        {userAttempts.length > 0 && (
          <div style={{ marginTop: '1.5rem' }}>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.1rem', color: 'var(--parchment)', marginBottom: '0.75rem' }}>
              Your Previous Attempts
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {userAttempts.map((attempt, i) => {
                const pct = Math.round((attempt.score / attempt.total) * 100)
                const color = pct >= 80 ? 'var(--sage)' : pct >= 60 ? 'var(--gold)' : 'var(--crimson)'
                return (
                  <div key={attempt.id} className="card" style={{ padding: '0.875rem 1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div>
                      <span style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)' }}>
                        Attempt #{userAttempts.length - i}  ·  {new Date(attempt.completedAt).toLocaleDateString()}
                      </span>
                      {attempt.timeTaken > 0 && (
                        <span style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)', marginLeft: '1rem' }}>
                          ⏱ {Math.floor(attempt.timeTaken / 60)}m {attempt.timeTaken % 60}s
                        </span>
                      )}
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <span style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.25rem', fontWeight: 600, color }}>
                        {pct}%
                      </span>
                      <span style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)', marginLeft: '0.5rem' }}>
                        ({attempt.score}/{attempt.total})
                      </span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

      </main>
    </div>
  )
}

function Stat({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <div>
      <div style={{ fontSize: '0.75rem', color: 'var(--parchment-dim)', marginBottom: '0.125rem' }}>{icon} {label}</div>
      <div style={{ fontWeight: 500, color: 'var(--parchment)', fontSize: '0.925rem' }}>{value}</div>
    </div>
  )
}
