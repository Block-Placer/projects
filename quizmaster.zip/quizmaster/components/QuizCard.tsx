import Link from 'next/link'

interface QuizCardProps {
  id: string
  title: string
  description: string
  category: string
  difficulty: string
  questionCount: number
  attemptCount?: number
  authorName?: string
  timeLimit?: number
  compact?: boolean
}

const CATEGORY_ICONS: Record<string, string> = {
  Geography: '🌍',
  Science: '🔬',
  History: '📜',
  Arts: '🎨',
  Mathematics: '📐',
  General: '🧠',
  Technology: '💻',
  Sports: '⚽',
  Music: '🎵',
  Movies: '🎬',
}

const DIFFICULTY_LABELS: Record<string, string> = {
  Easy: 'badge-easy',
  Medium: 'badge-medium',
  Hard: 'badge-hard',
}

export default function QuizCard({
  id, title, description, category, difficulty,
  questionCount, attemptCount, authorName, timeLimit, compact
}: QuizCardProps) {
  const icon = CATEGORY_ICONS[category] || '🧠'

  return (
    <Link href={`/quiz/${id}`} style={{ textDecoration: 'none', display: 'block' }}>
      <div
        className="card"
        style={{
          padding: compact ? '1rem 1.25rem' : '1.375rem 1.5rem',
          transition: 'border-color 0.2s, transform 0.2s, box-shadow 0.2s',
          cursor: 'pointer',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.75rem',
        }}
        onMouseEnter={e => {
          const el = e.currentTarget
          el.style.borderColor = 'rgba(212, 165, 116, 0.4)'
          el.style.transform = 'translateY(-2px)'
          el.style.boxShadow = '0 8px 32px rgba(0,0,0,0.3)'
        }}
        onMouseLeave={e => {
          const el = e.currentTarget
          el.style.borderColor = 'rgba(212, 165, 116, 0.15)'
          el.style.transform = 'translateY(0)'
          el.style.boxShadow = 'none'
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.75rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', flex: 1 }}>
            <span style={{ fontSize: '1.5rem', lineHeight: 1 }}>{icon}</span>
            <div>
              <h3 style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: compact ? '1rem' : '1.1rem',
                fontWeight: 600,
                color: 'var(--parchment)',
                lineHeight: 1.3,
              }}>{title}</h3>
              <p style={{ fontSize: '0.75rem', color: 'var(--parchment-dim)', marginTop: '0.125rem' }}>{category}</p>
            </div>
          </div>
          <span className={`badge ${DIFFICULTY_LABELS[difficulty] || 'badge-medium'}`}>{difficulty}</span>
        </div>

        {/* Description */}
        {!compact && (
          <p style={{
            fontSize: '0.875rem',
            color: 'var(--parchment-muted)',
            lineHeight: 1.5,
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}>{description}</p>
        )}

        {/* Footer */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '1rem',
          marginTop: 'auto',
          paddingTop: compact ? 0 : '0.25rem',
          borderTop: compact ? 'none' : '1px solid var(--border)',
        }}>
          <Stat icon="❓" label={`${questionCount} questions`} />
          {timeLimit && timeLimit > 0 && <Stat icon="⏱" label={`${Math.floor(timeLimit / 60)}m`} />}
          {attemptCount !== undefined && <Stat icon="👥" label={`${attemptCount} attempts`} />}
          {authorName && <Stat icon="✍️" label={authorName} />}
        </div>
      </div>
    </Link>
  )
}

function Stat({ icon, label }: { icon: string; label: string }) {
  return (
    <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.78rem', color: 'var(--parchment-dim)' }}>
      <span>{icon}</span>
      <span>{label}</span>
    </span>
  )
}
