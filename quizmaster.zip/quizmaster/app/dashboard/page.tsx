import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { redirect } from 'next/navigation'
import Navbar from '@/components/Navbar'
import QuizCard from '@/components/QuizCard'
import Link from 'next/link'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  const userId = session.user.id

  const [myQuizzes, recentAttempts, stats, publicQuizzes] = await Promise.all([
    prisma.quiz.findMany({
      where: { userId },
      include: { _count: { select: { questions: true, attempts: true } } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.quizAttempt.findMany({
      where: { userId },
      include: { quiz: { select: { title: true, id: true, category: true } } },
      orderBy: { completedAt: 'desc' },
      take: 8,
    }),
    prisma.quizAttempt.aggregate({
      where: { userId },
      _count: { id: true },
      _avg: { score: true },
      _sum: { score: true },
    }),
    prisma.quiz.findMany({
      where: { isPublic: true, userId: { not: userId } },
      include: {
        _count: { select: { questions: true, attempts: true } },
        user: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 6,
    }),
  ])

  const totalAttempts = stats._count.id
  const avgScore = stats._avg.score ? Math.round(stats._avg.score * 10) / 10 : 0

  // Best category
  const categoryStats: Record<string, { total: number; score: number }> = {}
  recentAttempts.forEach(a => {
    const cat = a.quiz.category
    if (!categoryStats[cat]) categoryStats[cat] = { total: 0, score: 0 }
    categoryStats[cat].total++
    categoryStats[cat].score += a.score
  })

  return (
    <div style={{ minHeight: '100vh', background: 'var(--ink)' }}>
      <Navbar />
      <main style={{ maxWidth: '1200px', margin: '0 auto', padding: '2.5rem 1.5rem' }}>

        {/* Header */}
        <div style={{ marginBottom: '2.5rem' }}>
          <h1 className="page-title">Welcome back, {session.user.name?.split(' ')[0]}</h1>
          <p style={{ color: 'var(--parchment-dim)', marginTop: '0.375rem' }}>
            Your knowledge dashboard
          </p>
        </div>

        {/* Stats */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
          gap: '1rem',
          marginBottom: '2.5rem',
        }}>
          {[
            { label: 'Quizzes Taken', value: totalAttempts, icon: '📝' },
            { label: 'Avg. Score', value: totalAttempts > 0 ? `${avgScore}` : '—', icon: '📊' },
            { label: 'Quizzes Created', value: myQuizzes.length, icon: '✍️' },
            { label: 'Total Points', value: stats._sum.score ?? 0, icon: '⭐' },
          ].map(stat => (
            <div key={stat.label} className="card" style={{ padding: '1.25rem 1.5rem' }}>
              <div style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>{stat.icon}</div>
              <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.875rem', fontWeight: 700, color: 'var(--gold)' }}>
                {stat.value}
              </div>
              <div style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)', marginTop: '0.125rem' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Two column layout */}
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1fr)', gap: '1.5rem', alignItems: 'start' }}>

          {/* Left: Recent activity */}
          <div>
            <SectionHeader title="Recent Activity" action={{ href: '/dashboard', label: '' }} />

            {recentAttempts.length === 0 ? (
              <div className="card" style={{ padding: '2.5rem', textAlign: 'center' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>🎯</div>
                <p style={{ color: 'var(--parchment-muted)', marginBottom: '1.25rem' }}>
                  You haven&apos;t taken any quizzes yet.
                </p>
                <Link href="#explore" className="btn-primary" style={{ textDecoration: 'none' }}>
                  Explore Quizzes
                </Link>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {recentAttempts.map(attempt => {
                  const pct = Math.round((attempt.score / attempt.total) * 100)
                  const color = pct >= 80 ? 'var(--sage)' : pct >= 60 ? 'var(--gold)' : 'var(--crimson)'
                  return (
                    <Link key={attempt.id} href={`/quiz/${attempt.quiz.id}`} style={{ textDecoration: 'none' }}>
                      <div className="card" style={{
                        padding: '0.875rem 1.25rem',
                        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        transition: 'border-color 0.2s',
                      }}
                        onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(212,165,116,0.35)')}
                        onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(212,165,116,0.15)')}
                      >
                        <div>
                          <p style={{ fontWeight: 500, color: 'var(--parchment)', fontSize: '0.925rem' }}>
                            {attempt.quiz.title}
                          </p>
                          <p style={{ fontSize: '0.775rem', color: 'var(--parchment-dim)', marginTop: '0.125rem' }}>
                            {new Date(attempt.completedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </p>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.25rem', fontWeight: 600, color }}>
                            {pct}%
                          </div>
                          <div style={{ fontSize: '0.75rem', color: 'var(--parchment-dim)' }}>
                            {attempt.score}/{attempt.total}
                          </div>
                        </div>
                      </div>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>

          {/* Right: My quizzes */}
          <div>
            <SectionHeader title="My Quizzes" action={{ href: '/quiz/create', label: '+ New' }} />

            {myQuizzes.length === 0 ? (
              <div className="card" style={{ padding: '2rem', textAlign: 'center' }}>
                <div style={{ fontSize: '2rem', marginBottom: '0.625rem' }}>📝</div>
                <p style={{ color: 'var(--parchment-muted)', fontSize: '0.875rem', marginBottom: '1rem' }}>
                  You haven&apos;t created any quizzes yet.
                </p>
                <Link href="/quiz/create" className="btn-primary" style={{ textDecoration: 'none', fontSize: '0.875rem' }}>
                  Create first quiz
                </Link>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {myQuizzes.map(quiz => (
                  <QuizCard
                    key={quiz.id}
                    id={quiz.id}
                    title={quiz.title}
                    description={quiz.description}
                    category={quiz.category}
                    difficulty={quiz.difficulty}
                    questionCount={quiz._count.questions}
                    attemptCount={quiz._count.attempts}
                    compact
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Explore section */}
        <div id="explore" style={{ marginTop: '3rem' }}>
          <SectionHeader title="Explore Quizzes" />
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
            gap: '1rem',
            marginTop: '1rem',
          }}>
            {publicQuizzes.map(quiz => (
              <QuizCard
                key={quiz.id}
                id={quiz.id}
                title={quiz.title}
                description={quiz.description}
                category={quiz.category}
                difficulty={quiz.difficulty}
                questionCount={quiz._count.questions}
                attemptCount={quiz._count.attempts}
                authorName={quiz.user.name}
                timeLimit={quiz.timeLimit}
              />
            ))}
          </div>
        </div>

      </main>
    </div>
  )
}

function SectionHeader({ title, action }: { title: string; action?: { href: string; label: string } }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.875rem' }}>
      <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.2rem', color: 'var(--parchment)' }}>
        {title}
      </h2>
      {action?.label && (
        <Link href={action.href} style={{ fontSize: '0.85rem', color: 'var(--gold)', textDecoration: 'none', fontWeight: 500 }}>
          {action.label}
        </Link>
      )}
    </div>
  )
}
