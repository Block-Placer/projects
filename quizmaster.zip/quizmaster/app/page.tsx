import Link from 'next/link'
import { prisma } from '@/lib/prisma'
import Navbar from '@/components/Navbar'
import QuizCard from '@/components/QuizCard'

async function getFeaturedQuizzes() {
  return prisma.quiz.findMany({
    where: { isPublic: true },
    include: {
      _count: { select: { questions: true, attempts: true } },
      user: { select: { name: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 6,
  })
}

export default async function Home() {
  const quizzes = await getFeaturedQuizzes()

  return (
    <div style={{ minHeight: '100vh', background: 'var(--ink)' }}>
      <Navbar />

      {/* Hero */}
      <section style={{
        padding: '5rem 1.5rem 4rem',
        textAlign: 'center',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Decorative background */}
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse 80% 50% at 50% 0%, rgba(212,165,116,0.08) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', top: '20%', left: '10%',
          width: '300px', height: '300px',
          background: 'radial-gradient(circle, rgba(107,158,122,0.05) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{ maxWidth: '720px', margin: '0 auto', position: 'relative' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
            background: 'rgba(212,165,116,0.1)',
            border: '1px solid rgba(212,165,116,0.2)',
            borderRadius: '999px',
            padding: '0.3rem 0.875rem',
            fontSize: '0.8rem',
            color: 'var(--gold)',
            fontWeight: 500,
            letterSpacing: '0.04em',
            marginBottom: '1.75rem',
            animation: 'fadeIn 0.5s ease-out',
          }}>
            <span>✦</span> THE KNOWLEDGE ARENA
          </div>

          <h1 style={{
            fontFamily: 'Playfair Display, serif',
            fontSize: 'clamp(2.5rem, 7vw, 4.5rem)',
            fontWeight: 700,
            lineHeight: 1.1,
            color: 'var(--parchment)',
            marginBottom: '1.25rem',
            animation: 'slideUp 0.5s ease-out',
          }}>
            Test Your Mind,<br />
            <em style={{ color: 'var(--gold)', fontStyle: 'italic' }}>Prove Your Worth</em>
          </h1>

          <p style={{
            fontSize: '1.125rem',
            color: 'var(--parchment-muted)',
            lineHeight: 1.7,
            marginBottom: '2.25rem',
            animation: 'slideUp 0.5s ease-out 0.1s both',
          }}>
            Explore hundreds of curated quizzes spanning science, history, arts, and beyond.
            Create your own, challenge friends, and track every victory.
          </p>

          <div style={{
            display: 'flex', gap: '0.875rem', justifyContent: 'center', flexWrap: 'wrap',
            animation: 'slideUp 0.5s ease-out 0.2s both',
          }}>
            <Link href="/register" className="btn-primary" style={{ padding: '0.75rem 1.75rem', fontSize: '1rem', textDecoration: 'none' }}>
              Start for free →
            </Link>
            <Link href="#quizzes" className="btn-secondary" style={{ padding: '0.75rem 1.75rem', fontSize: '1rem', textDecoration: 'none' }}>
              Browse quizzes
            </Link>
          </div>
        </div>

        {/* Stats bar */}
        <div style={{
          display: 'flex', justifyContent: 'center', gap: '3rem', flexWrap: 'wrap',
          marginTop: '3.5rem',
          animation: 'fadeIn 0.6s ease-out 0.4s both',
        }}>
          {[
            { value: '50+', label: 'Quizzes' },
            { value: '500+', label: 'Questions' },
            { value: '5', label: 'Categories' },
            { value: '∞', label: 'Knowledge' },
          ].map(stat => (
            <div key={stat.label} style={{ textAlign: 'center' }}>
              <div style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: '1.75rem',
                fontWeight: 700,
                color: 'var(--gold)',
              }}>{stat.value}</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)', marginTop: '0.125rem' }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Join by code */}
      <section style={{ padding: '0 1.5rem 3rem' }}>
        <div style={{ maxWidth: '480px', margin: '0 auto' }}>
          <JoinByCode />
        </div>
      </section>

      {/* Featured Quizzes */}
      <section id="quizzes" style={{ padding: '1rem 1.5rem 5rem' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ marginBottom: '2rem' }}>
            <h2 style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: '1.875rem',
              color: 'var(--parchment)',
            }}>Featured Quizzes</h2>
            <p style={{ color: 'var(--parchment-dim)', marginTop: '0.25rem', fontSize: '0.9rem' }}>
              Hand-picked to challenge every level of expertise
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
            gap: '1rem',
          }}>
            {quizzes.map(quiz => (
              <QuizCard
                key={quiz.id}
                id={quiz.id}
                title={quiz.title}
                description={quiz.description}
                category={quiz.category}
                difficulty={quiz.difficulty}
                questionCount={quiz._count.questions}
                attemptCount={quiz._count.attempts}
                authorName={quiz.user.name}
                timeLimit={quiz.timeLimit}
              />
            ))}
          </div>

          {quizzes.length === 0 && (
            <div style={{
              textAlign: 'center', padding: '4rem 1rem',
              color: 'var(--parchment-dim)',
            }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📚</div>
              <p>No quizzes yet. Be the first to create one!</p>
              <Link href="/quiz/create" className="btn-primary" style={{ display: 'inline-flex', marginTop: '1.5rem', textDecoration: 'none' }}>
                Create a Quiz
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        borderTop: '1px solid var(--border)',
        padding: '2rem 1.5rem',
        textAlign: 'center',
        color: 'var(--parchment-dim)',
        fontSize: '0.85rem',
      }}>
        <p>QuizMaster — Built for curious minds</p>
      </footer>
    </div>
  )
}

function JoinByCode() {
  return (
    <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
      <p style={{ fontSize: '0.875rem', color: 'var(--parchment-muted)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
        <span>🔑</span> Have an invite code?
      </p>
      <form action="/quiz/join" method="GET" style={{ display: 'flex', gap: '0.5rem' }}>
        <input
          name="code"
          className="input"
          placeholder="Enter invite code…"
          style={{ flex: 1 }}
          required
        />
        <button type="submit" className="btn-primary" style={{ whiteSpace: 'nowrap' }}>
          Join Quiz
        </button>
      </form>
    </div>
  )
}
