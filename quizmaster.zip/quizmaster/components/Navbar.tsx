'use client'

import { useSession, signOut } from 'next-auth/react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'

export default function Navbar() {
  const { data: session } = useSession()
  const pathname = usePathname()
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <nav style={{
      background: 'rgba(20, 18, 16, 0.92)',
      backdropFilter: 'blur(12px)',
      borderBottom: '1px solid rgba(212, 165, 116, 0.12)',
      position: 'sticky',
      top: 0,
      zIndex: 50,
    }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px' }}>
          {/* Logo */}
          <Link href="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <div style={{
              width: '32px', height: '32px',
              background: 'var(--gold)',
              borderRadius: '8px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1rem',
            }}>📖</div>
            <span style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: '1.2rem',
              fontWeight: 700,
              color: 'var(--parchment)',
            }}>QuizMaster</span>
          </Link>

          {/* Desktop Nav */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
            {session ? (
              <>
                <NavLink href="/dashboard" active={pathname.startsWith('/dashboard')}>Dashboard</NavLink>
                <NavLink href="/quiz/create" active={pathname === '/quiz/create'}>Create Quiz</NavLink>
                <div style={{ width: '1px', height: '20px', background: 'var(--border)', margin: '0 0.5rem' }} />
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <span style={{ fontSize: '0.875rem', color: 'var(--parchment-muted)' }}>
                    {session.user.name}
                  </span>
                  <button
                    onClick={() => signOut({ callbackUrl: '/' })}
                    className="btn-secondary"
                    style={{ padding: '0.4rem 0.875rem', fontSize: '0.875rem' }}
                  >
                    Sign out
                  </button>
                </div>
              </>
            ) : (
              <>
                <NavLink href="/login" active={pathname === '/login'}>Sign in</NavLink>
                <Link href="/register" className="btn-primary" style={{ padding: '0.4rem 0.875rem', fontSize: '0.875rem', textDecoration: 'none' }}>
                  Get started
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}

function NavLink({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      style={{
        padding: '0.4rem 0.75rem',
        borderRadius: '8px',
        fontSize: '0.9rem',
        fontWeight: 500,
        textDecoration: 'none',
        color: active ? 'var(--gold)' : 'var(--parchment-muted)',
        background: active ? 'rgba(212, 165, 116, 0.08)' : 'transparent',
        transition: 'color 0.2s, background 0.2s',
      }}
    >
      {children}
    </Link>
  )
}
