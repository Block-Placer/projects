'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'

interface QuestionDraft {
  text: string
  options: [string, string, string, string]
  correctAnswer: number
  explanation: string
}

const emptyQuestion = (): QuestionDraft => ({
  text: '',
  options: ['', '', '', ''],
  correctAnswer: 0,
  explanation: '',
})

const CATEGORIES = ['General', 'Geography', 'Science', 'History', 'Arts', 'Mathematics', 'Technology', 'Sports', 'Music', 'Movies']
const DIFFICULTIES = ['Easy', 'Medium', 'Hard']

export default function CreateQuizPage() {
  const router = useRouter()
  const [step, setStep] = useState<'meta' | 'questions' | 'review'>('meta')
  const [meta, setMeta] = useState({
    title: '',
    description: '',
    category: 'General',
    difficulty: 'Medium',
    isPublic: true,
    timeLimit: 0,
  })
  const [questions, setQuestions] = useState<QuestionDraft[]>([emptyQuestion()])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const addQuestion = () => setQuestions(q => [...q, emptyQuestion()])
  const removeQuestion = (i: number) => setQuestions(q => q.filter((_, idx) => idx !== i))

  const updateQuestion = (i: number, field: keyof QuestionDraft, value: unknown) => {
    setQuestions(q => q.map((qn, idx) => idx === i ? { ...qn, [field]: value } : qn))
  }

  const updateOption = (qi: number, oi: number, value: string) => {
    setQuestions(q => q.map((qn, idx) => {
      if (idx !== qi) return qn
      const opts = [...qn.options] as [string, string, string, string]
      opts[oi] = value
      return { ...qn, options: opts }
    }))
  }

  const handleSubmit = async () => {
    setError('')
    // Validate
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i]
      if (!q.text.trim()) { setError(`Question ${i + 1} is missing text.`); return }
      if (q.options.some(o => !o.trim())) { setError(`Question ${i + 1} has empty options.`); return }
    }

    setLoading(true)
    try {
      const res = await fetch('/api/quizzes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...meta,
          questions: questions.map((q, i) => ({ ...q, order: i })),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to create quiz')
      router.push(`/quiz/${data.id}`)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Something went wrong')
      setLoading(false)
    }
  }

  const inputStyle = {
    width: '100%',
    background: 'var(--ink-50)',
    border: '1px solid rgba(212,165,116,0.15)',
    borderRadius: '8px',
    padding: '0.625rem 0.875rem',
    color: 'var(--parchment)',
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '0.9375rem',
  }

  const labelStyle = {
    fontSize: '0.85rem',
    color: 'var(--parchment-muted)',
    fontWeight: 500 as const,
    display: 'block' as const,
    marginBottom: '0.375rem',
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--ink)' }}>
      <Navbar />
      <main style={{ maxWidth: '760px', margin: '0 auto', padding: '2.5rem 1.5rem' }}>
        <div style={{ marginBottom: '2rem' }}>
          <h1 className="page-title">Create a Quiz</h1>
          <p style={{ color: 'var(--parchment-dim)', marginTop: '0.375rem' }}>
            Build your own quiz and share it with the world
          </p>
        </div>

        {/* Steps indicator */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '2rem' }}>
          {(['meta', 'questions', 'review'] as const).map((s, i) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1 }}>
              <div style={{
                width: '28px', height: '28px', borderRadius: '50%',
                background: step === s ? 'var(--gold)' : (
                  (i === 0 && step !== 'meta') || (i === 1 && step === 'review')
                    ? 'rgba(212,165,116,0.3)' : 'var(--ink-50)'
                ),
                color: step === s ? 'var(--ink)' : 'var(--parchment-muted)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.8rem', fontWeight: 700, flexShrink: 0,
                transition: 'all 0.2s',
              }}>
                {i + 1}
              </div>
              <span style={{ fontSize: '0.8rem', color: step === s ? 'var(--gold)' : 'var(--parchment-dim)', fontWeight: step === s ? 600 : 400 }}>
                {s === 'meta' ? 'Details' : s === 'questions' ? 'Questions' : 'Review'}
              </span>
              {i < 2 && <div style={{ flex: 1, height: '1px', background: 'var(--border)' }} />}
            </div>
          ))}
        </div>

        {error && (
          <div style={{
            background: 'rgba(196,103,90,0.12)', border: '1px solid rgba(196,103,90,0.3)',
            borderRadius: '8px', padding: '0.75rem 1rem', color: 'var(--crimson)',
            fontSize: '0.875rem', marginBottom: '1.25rem',
          }}>
            {error}
          </div>
        )}

        {/* STEP 1: Meta */}
        {step === 'meta' && (
          <div className="card" style={{ padding: '1.75rem' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              <div>
                <label style={labelStyle}>Quiz Title *</label>
                <input
                  style={inputStyle}
                  placeholder="e.g. World Capitals Challenge"
                  value={meta.title}
                  onChange={e => setMeta(m => ({ ...m, title: e.target.value }))}
                  maxLength={100}
                />
              </div>

              <div>
                <label style={labelStyle}>Description *</label>
                <textarea
                  style={{ ...inputStyle, minHeight: '80px', resize: 'vertical' }}
                  placeholder="What is this quiz about?"
                  value={meta.description}
                  onChange={e => setMeta(m => ({ ...m, description: e.target.value }))}
                  maxLength={500}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={labelStyle}>Category</label>
                  <select
                    style={inputStyle}
                    value={meta.category}
                    onChange={e => setMeta(m => ({ ...m, category: e.target.value }))}
                  >
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                <div>
                  <label style={labelStyle}>Difficulty</label>
                  <select
                    style={inputStyle}
                    value={meta.difficulty}
                    onChange={e => setMeta(m => ({ ...m, difficulty: e.target.value }))}
                  >
                    {DIFFICULTIES.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label style={labelStyle}>Time Limit (minutes)</label>
                  <input
                    style={inputStyle}
                    type="number"
                    min={0}
                    max={60}
                    placeholder="0 = no limit"
                    value={meta.timeLimit === 0 ? '' : meta.timeLimit / 60}
                    onChange={e => setMeta(m => ({ ...m, timeLimit: parseInt(e.target.value) > 0 ? parseInt(e.target.value) * 60 : 0 }))}
                  />
                </div>

                <div>
                  <label style={labelStyle}>Visibility</label>
                  <select
                    style={inputStyle}
                    value={meta.isPublic ? 'public' : 'private'}
                    onChange={e => setMeta(m => ({ ...m, isPublic: e.target.value === 'public' }))}
                  >
                    <option value="public">Public (anyone can find it)</option>
                    <option value="private">Private (invite only)</option>
                  </select>
                </div>
              </div>
            </div>

            <div style={{ marginTop: '1.75rem', display: 'flex', justifyContent: 'flex-end' }}>
              <button
                className="btn-primary"
                onClick={() => {
                  if (!meta.title.trim() || !meta.description.trim()) {
                    setError('Please fill in title and description.')
                    return
                  }
                  setError('')
                  setStep('questions')
                }}
              >
                Next: Add Questions →
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Questions */}
        {step === 'questions' && (
          <div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {questions.map((q, qi) => (
                <div key={qi} className="card" style={{ padding: '1.5rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                    <h3 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1rem', color: 'var(--gold)' }}>
                      Question {qi + 1}
                    </h3>
                    {questions.length > 1 && (
                      <button
                        onClick={() => removeQuestion(qi)}
                        style={{ background: 'none', border: 'none', color: 'var(--crimson)', cursor: 'pointer', fontSize: '0.875rem', padding: '0.25rem 0.5rem' }}
                      >
                        Remove
                      </button>
                    )}
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <div>
                      <label style={labelStyle}>Question Text *</label>
                      <textarea
                        style={{ ...inputStyle, minHeight: '60px', resize: 'vertical' }}
                        placeholder="What is your question?"
                        value={q.text}
                        onChange={e => updateQuestion(qi, 'text', e.target.value)}
                      />
                    </div>

                    <div>
                      <label style={labelStyle}>Answer Options * <span style={{ color: 'var(--parchment-dim)', fontWeight: 400 }}>(select the correct one)</span></label>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        {q.options.map((opt, oi) => (
                          <div key={oi} style={{ display: 'flex', gap: '0.625rem', alignItems: 'center' }}>
                            <button
                              onClick={() => updateQuestion(qi, 'correctAnswer', oi)}
                              style={{
                                width: '28px', height: '28px', borderRadius: '6px', flexShrink: 0,
                                background: q.correctAnswer === oi ? 'var(--sage)' : 'var(--ink-50)',
                                border: `1px solid ${q.correctAnswer === oi ? 'var(--sage)' : 'rgba(212,165,116,0.2)'}`,
                                color: q.correctAnswer === oi ? 'white' : 'var(--parchment-dim)',
                                cursor: 'pointer', fontSize: '0.8rem', fontWeight: 700,
                                transition: 'all 0.15s',
                              }}
                            >
                              {String.fromCharCode(65 + oi)}
                            </button>
                            <input
                              style={{ ...inputStyle }}
                              placeholder={`Option ${String.fromCharCode(65 + oi)}`}
                              value={opt}
                              onChange={e => updateOption(qi, oi, e.target.value)}
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label style={labelStyle}>Explanation <span style={{ color: 'var(--parchment-dim)', fontWeight: 400 }}>(optional, shown after answering)</span></label>
                      <input
                        style={inputStyle}
                        placeholder="Why is this the correct answer?"
                        value={q.explanation}
                        onChange={e => updateQuestion(qi, 'explanation', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={addQuestion}
              className="btn-secondary"
              style={{ width: '100%', justifyContent: 'center', padding: '0.75rem', marginTop: '1rem', borderStyle: 'dashed' }}
            >
              + Add another question
            </button>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'space-between', marginTop: '1.5rem' }}>
              <button className="btn-secondary" onClick={() => setStep('meta')}>
                ← Back
              </button>
              <button
                className="btn-primary"
                onClick={() => {
                  for (let i = 0; i < questions.length; i++) {
                    const q = questions[i]
                    if (!q.text.trim()) { setError(`Question ${i + 1} needs text.`); return }
                    if (q.options.some(o => !o.trim())) { setError(`Question ${i + 1} has empty options.`); return }
                  }
                  setError('')
                  setStep('review')
                }}
              >
                Review →
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Review */}
        {step === 'review' && (
          <div>
            <div className="card" style={{ padding: '1.75rem', marginBottom: '1rem' }}>
              <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.25rem', color: 'var(--parchment)', marginBottom: '1rem' }}>
                {meta.title}
              </h2>
              <p style={{ color: 'var(--parchment-muted)', lineHeight: 1.6, marginBottom: '1rem' }}>{meta.description}</p>
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <span className="badge badge-medium">{meta.difficulty}</span>
                <span className="badge" style={{ background: 'rgba(212,165,116,0.1)', color: 'var(--gold-light)', border: '1px solid rgba(212,165,116,0.2)' }}>
                  {meta.category}
                </span>
                <span style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)' }}>❓ {questions.length} questions</span>
                {meta.timeLimit > 0 && <span style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)' }}>⏱ {meta.timeLimit / 60}m</span>}
                <span style={{ fontSize: '0.8rem', color: 'var(--parchment-dim)' }}>{meta.isPublic ? '🌐 Public' : '🔒 Private'}</span>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.5rem' }}>
              {questions.map((q, i) => (
                <div key={i} className="card" style={{ padding: '0.875rem 1.25rem', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                  <span style={{ color: 'var(--gold)', fontSize: '0.8rem', fontWeight: 700, flexShrink: 0, marginTop: '0.125rem' }}>Q{i + 1}</span>
                  <div style={{ flex: 1 }}>
                    <p style={{ color: 'var(--parchment)', fontSize: '0.9rem' }}>{q.text}</p>
                    <p style={{ color: 'var(--sage)', fontSize: '0.8rem', marginTop: '0.25rem' }}>
                      ✓ {q.options[q.correctAnswer]}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'space-between' }}>
              <button className="btn-secondary" onClick={() => setStep('questions')}>
                ← Edit Questions
              </button>
              <button
                className="btn-primary"
                onClick={handleSubmit}
                disabled={loading}
                style={{ padding: '0.75rem 2rem' }}
              >
                {loading ? 'Publishing…' : '🚀 Publish Quiz'}
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
