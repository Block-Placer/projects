import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create system user
  const hashedPassword = await bcrypt.hash('quizmaster2024!', 12)
  const systemUser = await prisma.user.upsert({
    where: { email: 'admin@quizmaster.app' },
    update: {},
    create: {
      name: 'QuizMaster',
      email: 'admin@quizmaster.app',
      password: hashedPassword,
    },
  })

  // Seed quizzes
  const quizzes = [
    {
      title: 'World Geography',
      description: 'Test your knowledge of countries, capitals, continents, and geographical wonders from around the globe.',
      category: 'Geography',
      difficulty: 'Medium',
      inviteCode: 'GEO-2024',
      timeLimit: 300,
      questions: [
        { text: 'What is the capital of Australia?', options: ['Sydney', 'Melbourne', 'Canberra', 'Brisbane'], correctAnswer: 2, explanation: 'Canberra is the capital, chosen as a compromise between Sydney and Melbourne.' },
        { text: 'Which is the longest river in the world?', options: ['Amazon', 'Nile', 'Yangtze', 'Mississippi'], correctAnswer: 1, explanation: 'The Nile stretches approximately 6,650 km through northeastern Africa.' },
        { text: 'How many countries are in Africa?', options: ['48', '52', '54', '58'], correctAnswer: 2, explanation: 'Africa has 54 recognized sovereign states.' },
        { text: 'Which country has the most natural lakes?', options: ['Russia', 'USA', 'Brazil', 'Canada'], correctAnswer: 3, explanation: 'Canada has over 2 million lakes, more than any other country.' },
        { text: 'What is the smallest country in the world by area?', options: ['Monaco', 'San Marino', 'Vatican City', 'Liechtenstein'], correctAnswer: 2, explanation: 'Vatican City covers just 0.44 km² within Rome, Italy.' },
        { text: 'Which ocean is the largest?', options: ['Atlantic', 'Indian', 'Pacific', 'Arctic'], correctAnswer: 2, explanation: 'The Pacific Ocean covers more than 165 million km², about 46% of the world\'s water surface.' },
        { text: 'What is the capital of Canada?', options: ['Toronto', 'Vancouver', 'Montreal', 'Ottawa'], correctAnswer: 3, explanation: 'Ottawa has been Canada\'s capital since 1857.' },
        { text: 'Which mountain range separates Europe from Asia?', options: ['Alps', 'Himalayas', 'Ural Mountains', 'Caucasus'], correctAnswer: 2, explanation: 'The Ural Mountains run through Russia and form part of the boundary between Europe and Asia.' },
        { text: 'The Sahara Desert is primarily located on which continent?', options: ['Asia', 'Africa', 'South America', 'Australia'], correctAnswer: 1, explanation: 'The Sahara is the world\'s largest hot desert, covering much of North Africa.' },
        { text: 'Which country has the largest population?', options: ['USA', 'India', 'China', 'Indonesia'], correctAnswer: 1, explanation: 'As of 2023, India surpassed China to become the world\'s most populous country.' },
      ],
    },
    {
      title: 'Science & Technology',
      description: 'Explore the frontiers of scientific discovery and technological innovation across physics, biology, chemistry, and computing.',
      category: 'Science',
      difficulty: 'Hard',
      inviteCode: 'SCI-2024',
      timeLimit: 360,
      questions: [
        { text: 'What is the speed of light in a vacuum?', options: ['300,000 km/s', '150,000 km/s', '450,000 km/s', '250,000 km/s'], correctAnswer: 0, explanation: 'Light travels at approximately 299,792 km/s in a vacuum.' },
        { text: 'Which element has the chemical symbol "Au"?', options: ['Silver', 'Aluminum', 'Gold', 'Argon'], correctAnswer: 2, explanation: 'Au comes from the Latin word "aurum" meaning gold.' },
        { text: 'What is the powerhouse of the cell?', options: ['Nucleus', 'Ribosome', 'Mitochondria', 'Golgi apparatus'], correctAnswer: 2, explanation: 'Mitochondria produce ATP, the energy currency of the cell, through cellular respiration.' },
        { text: 'What does DNA stand for?', options: ['Deoxyribonucleic Acid', 'Dinucleic Amino Acid', 'Deoxyribose Nitrogen Acid', 'Double Nucleic Acid'], correctAnswer: 0, explanation: 'DNA (Deoxyribonucleic Acid) carries the genetic blueprint of all living organisms.' },
        { text: 'Which planet has the most moons in our solar system?', options: ['Jupiter', 'Saturn', 'Uranus', 'Neptune'], correctAnswer: 1, explanation: 'Saturn has 146 confirmed moons, more than any other planet as of 2023.' },
        { text: 'What is the atomic number of Carbon?', options: ['4', '6', '8', '12'], correctAnswer: 1, explanation: 'Carbon has 6 protons in its nucleus, giving it atomic number 6.' },
        { text: 'Who developed the theory of general relativity?', options: ['Isaac Newton', 'Niels Bohr', 'Albert Einstein', 'Max Planck'], correctAnswer: 2, explanation: 'Einstein published his general theory of relativity in 1915.' },
        { text: 'What is the most abundant gas in Earth\'s atmosphere?', options: ['Oxygen', 'Carbon Dioxide', 'Argon', 'Nitrogen'], correctAnswer: 3, explanation: 'Nitrogen makes up about 78% of Earth\'s atmosphere.' },
        { text: 'In computing, what does "CPU" stand for?', options: ['Central Processing Unit', 'Computer Processing Unit', 'Core Program Utility', 'Central Program Uplink'], correctAnswer: 0, explanation: 'The Central Processing Unit is the primary component that executes instructions in a computer.' },
        { text: 'What is the half-life of Carbon-14?', options: ['570 years', '5,730 years', '57,300 years', '573,000 years'], correctAnswer: 1, explanation: 'Carbon-14 has a half-life of approximately 5,730 years, making it useful for radiocarbon dating.' },
      ],
    },
    {
      title: 'World History',
      description: 'Journey through the pivotal events, empires, and figures that shaped our world from ancient civilizations to the modern era.',
      category: 'History',
      difficulty: 'Medium',
      inviteCode: 'HIS-2024',
      timeLimit: 300,
      questions: [
        { text: 'In which year did World War II end?', options: ['1943', '1944', '1945', '1946'], correctAnswer: 2, explanation: 'WWII ended in 1945 with Germany\'s surrender in May and Japan\'s in September.' },
        { text: 'Who was the first person to walk on the Moon?', options: ['Buzz Aldrin', 'Neil Armstrong', 'Yuri Gagarin', 'John Glenn'], correctAnswer: 1, explanation: 'Neil Armstrong became the first human on the Moon on July 20, 1969, during Apollo 11.' },
        { text: 'The ancient city of Rome was traditionally founded in which year?', options: ['453 BCE', '753 BCE', '753 CE', '1000 BCE'], correctAnswer: 1, explanation: 'According to tradition, Rome was founded in 753 BCE by Romulus.' },
        { text: 'Which empire was the largest in history by land area?', options: ['British Empire', 'Mongol Empire', 'Roman Empire', 'Russian Empire'], correctAnswer: 0, explanation: 'At its height, the British Empire covered about 24% of the Earth\'s total land area.' },
        { text: 'The French Revolution began in which year?', options: ['1776', '1783', '1789', '1799'], correctAnswer: 2, explanation: 'The French Revolution began in 1789 with the storming of the Bastille on July 14.' },
        { text: 'Who wrote "The Communist Manifesto"?', options: ['Lenin and Stalin', 'Marx and Engels', 'Mao and Trotsky', 'Proudhon and Bakunin'], correctAnswer: 1, explanation: 'Karl Marx and Friedrich Engels published The Communist Manifesto in 1848.' },
        { text: 'The Berlin Wall fell in which year?', options: ['1985', '1987', '1989', '1991'], correctAnswer: 2, explanation: 'The Berlin Wall fell on November 9, 1989, marking the end of the Cold War era.' },
        { text: 'Which ancient wonder of the world still stands today?', options: ['Hanging Gardens of Babylon', 'Great Pyramid of Giza', 'Colossus of Rhodes', 'Lighthouse of Alexandria'], correctAnswer: 1, explanation: 'The Great Pyramid of Giza is the only ancient wonder still largely intact.' },
        { text: 'Who was the first President of the United States?', options: ['Thomas Jefferson', 'John Adams', 'Benjamin Franklin', 'George Washington'], correctAnswer: 3, explanation: 'George Washington served as the first U.S. President from 1789 to 1797.' },
        { text: 'The Renaissance period originated in which country?', options: ['France', 'Germany', 'Italy', 'England'], correctAnswer: 2, explanation: 'The Renaissance began in Italy in the 14th century, flourishing in cities like Florence.' },
      ],
    },
    {
      title: 'Literature & The Arts',
      description: 'Dive into the world of great books, paintings, music, and cultural movements that define human creativity.',
      category: 'Arts',
      difficulty: 'Hard',
      inviteCode: 'ART-2024',
      timeLimit: 300,
      questions: [
        { text: 'Who painted the Mona Lisa?', options: ['Michelangelo', 'Raphael', 'Leonardo da Vinci', 'Caravaggio'], correctAnswer: 2, explanation: 'Leonardo da Vinci painted the Mona Lisa between approximately 1503 and 1519.' },
        { text: 'Which Shakespeare play features the character Hamlet?', options: ['Macbeth', 'Othello', 'Hamlet', 'King Lear'], correctAnswer: 2, explanation: 'Hamlet, Prince of Denmark was written around 1600 and is one of Shakespeare\'s greatest tragedies.' },
        { text: 'Who composed the "Four Seasons"?', options: ['Bach', 'Vivaldi', 'Mozart', 'Beethoven'], correctAnswer: 1, explanation: 'Antonio Vivaldi composed Le quattro stagioni (The Four Seasons) around 1718.' },
        { text: 'In which museum is the Mona Lisa housed?', options: ['The Uffizi Gallery', 'The Louvre', 'The Prado', 'The Vatican Museums'], correctAnswer: 1, explanation: 'The Mona Lisa has been on permanent display at the Louvre in Paris since 1797.' },
        { text: 'Who wrote "Pride and Prejudice"?', options: ['Charlotte Brontë', 'George Eliot', 'Jane Austen', 'Mary Shelley'], correctAnswer: 2, explanation: 'Jane Austen published Pride and Prejudice in 1813.' },
        { text: 'What art movement is Salvador Dalí associated with?', options: ['Cubism', 'Impressionism', 'Surrealism', 'Expressionism'], correctAnswer: 2, explanation: 'Dalí was a prominent member of the Surrealist movement, known for his dreamlike imagery.' },
        { text: 'Which novel opens with "Call me Ishmael"?', options: ['The Old Man and the Sea', 'Moby Dick', 'Billy Budd', 'Lord Jim'], correctAnswer: 1, explanation: 'Herman Melville\'s Moby Dick (1851) begins with this iconic opening line.' },
        { text: 'Who sculpted "David"?', options: ['Donatello', 'Bernini', 'Michelangelo', 'Canova'], correctAnswer: 2, explanation: 'Michelangelo\'s David was carved between 1501 and 1504 and stands in Florence\'s Galleria dell\'Accademia.' },
        { text: 'The Impressionist art movement began in which country?', options: ['England', 'Germany', 'France', 'Spain'], correctAnswer: 2, explanation: 'Impressionism began in France in the 1860s with artists like Monet, Renoir, and Degas.' },
        { text: 'Who wrote "1984"?', options: ['Aldous Huxley', 'George Orwell', 'Ray Bradbury', 'H.G. Wells'], correctAnswer: 1, explanation: 'George Orwell published 1984 in 1949, a dystopian novel about totalitarianism.' },
      ],
    },
    {
      title: 'Mathematics & Logic',
      description: 'Sharpen your mind with puzzles, theorems, and numerical challenges spanning arithmetic, algebra, and beyond.',
      category: 'Mathematics',
      difficulty: 'Hard',
      inviteCode: 'MTH-2024',
      timeLimit: 420,
      questions: [
        { text: 'What is the value of π (pi) to two decimal places?', options: ['3.12', '3.14', '3.16', '3.18'], correctAnswer: 1, explanation: 'Pi is approximately 3.14159, commonly rounded to 3.14.' },
        { text: 'What is the square root of 144?', options: ['11', '12', '13', '14'], correctAnswer: 1, explanation: '12 × 12 = 144.' },
        { text: 'In a right triangle, if the two legs are 3 and 4, what is the hypotenuse?', options: ['5', '6', '7', '8'], correctAnswer: 0, explanation: 'By the Pythagorean theorem: √(3² + 4²) = √(9 + 16) = √25 = 5.' },
        { text: 'What is 2 to the power of 10?', options: ['512', '1024', '2048', '256'], correctAnswer: 1, explanation: '2^10 = 1024, a fundamental number in computing (1 kilobyte).' },
        { text: 'What is the sum of interior angles of a triangle?', options: ['90°', '180°', '270°', '360°'], correctAnswer: 1, explanation: 'The three interior angles of any triangle always sum to 180°.' },
        { text: 'What is the next prime number after 13?', options: ['15', '16', '17', '19'], correctAnswer: 2, explanation: '17 is prime (divisible only by 1 and itself). 15 = 3×5, 16 = 2^4.' },
        { text: 'If f(x) = 2x + 3, what is f(5)?', options: ['10', '13', '15', '16'], correctAnswer: 1, explanation: 'f(5) = 2(5) + 3 = 10 + 3 = 13.' },
        { text: 'What is 15% of 200?', options: ['25', '30', '35', '40'], correctAnswer: 1, explanation: '15% of 200 = 0.15 × 200 = 30.' },
        { text: 'The Fibonacci sequence starts 1, 1, 2, 3, 5... What is the next number?', options: ['6', '7', '8', '9'], correctAnswer: 2, explanation: 'Each number is the sum of the two preceding: 3 + 5 = 8.' },
        { text: 'What is the area of a circle with radius 7? (Use π ≈ 3.14)', options: ['43.96', '153.86', '49', '21.98'], correctAnswer: 1, explanation: 'Area = πr² = 3.14 × 7² = 3.14 × 49 ≈ 153.86.' },
      ],
    },
  ]

  for (const quizData of quizzes) {
    const { questions, ...quizInfo } = quizData
    const existing = await prisma.quiz.findUnique({ where: { inviteCode: quizInfo.inviteCode } })
    if (existing) {
      console.log(`  ⏭  Skipping "${quizInfo.title}" (already exists)`)
      continue
    }

    const quiz = await prisma.quiz.create({
      data: {
        ...quizInfo,
        userId: systemUser.id,
        questions: {
          create: questions.map((q, i) => ({
            text: q.text,
            options: JSON.stringify(q.options),
            correctAnswer: q.correctAnswer,
            explanation: q.explanation,
            order: i,
          })),
        },
      },
    })
    console.log(`  ✅ Created quiz: "${quiz.title}"`)
  }

  console.log('\n✨ Seeding complete!')
  console.log('   Admin login: admin@quizmaster.app / quizmaster2024!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
