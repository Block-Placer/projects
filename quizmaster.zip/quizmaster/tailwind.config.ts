import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#141210',
          50: '#2e2a25',
          100: '#1e1b17',
          200: '#141210',
        },
        parchment: {
          DEFAULT: '#f0ead8',
          muted: '#b8ae99',
          dim: '#7a7266',
        },
        gold: {
          DEFAULT: '#d4a574',
          light: '#e8c49a',
          dark: '#a87850',
        },
        sage: {
          DEFAULT: '#6b9e7a',
          light: '#8fc09f',
          dark: '#4a7a5a',
        },
        crimson: {
          DEFAULT: '#c4675a',
          light: '#e08a7e',
          dark: '#9e4a3e',
        },
        slate: {
          custom: '#2e2a25',
        }
      },
      fontFamily: {
        serif: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      backgroundImage: {
        'grain': "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.4'/%3E%3C/svg%3E\")",
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'pulse-gold': 'pulseGold 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseGold: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(212, 165, 116, 0.3)' },
          '50%': { boxShadow: '0 0 0 8px rgba(212, 165, 116, 0)' },
        },
      },
    },
  },
  plugins: [],
}
export default config
