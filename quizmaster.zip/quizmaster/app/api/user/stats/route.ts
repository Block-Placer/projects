import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const [attempts, quizCount] = await Promise.all([
    prisma.quizAttempt.findMany({
      where: { userId: session.user.id },
      include: { quiz: { select: { title: true, category: true } } },
      orderBy: { completedAt: 'desc' },
    }),
    prisma.quiz.count({ where: { userId: session.user.id } }),
  ])

  const totalAttempts = attempts.length
  const avgScore = totalAttempts > 0
    ? attempts.reduce((sum, a) => sum + (a.score / a.total) * 100, 0) / totalAttempts
    : 0

  // Category breakdown
  const byCategory: Record<string, { attempts: number; avgPct: number }> = {}
  attempts.forEach(a => {
    const cat = a.quiz.category
    if (!byCategory[cat]) byCategory[cat] = { attempts: 0, avgPct: 0 }
    byCategory[cat].attempts++
    byCategory[cat].avgPct += (a.score / a.total) * 100
  })
  Object.keys(byCategory).forEach(cat => {
    byCategory[cat].avgPct = Math.round(byCategory[cat].avgPct / byCategory[cat].attempts)
  })

  return NextResponse.json({
    totalAttempts,
    avgScore: Math.round(avgScore),
    quizCount,
    byCategory,
    recentAttempts: attempts.slice(0, 10),
  })
}
