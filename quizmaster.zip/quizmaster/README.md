# 📖 QuizMaster

A full-featured quiz platform built with Next.js 14, Prisma, PostgreSQL, and NextAuth.

---

## ✨ Features

- **User Authentication** — Register, sign in, sign out with NextAuth credentials
- **Browse Quizzes** — Explore public quizzes by category and difficulty
- **Take Quizzes** — Interactive quiz player with timer, answer feedback, and explanations
- **Progress Tracking** — Dashboard with your scores, streaks, and category breakdown
- **Create Quizzes** — 3-step wizard to build quizzes with custom questions
- **Invite Others** — Each quiz has a unique invite code to share with friends
- **Join by Code** — Enter an invite code on the homepage to jump straight to a quiz
- **Leaderboards** — Top attempts per quiz visible to all players
- **Seeded Content** — 5 rich quizzes (50 questions) across Geography, Science, History, Arts & Mathematics

---

## 🛠 Tech Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS (dark academic theme) |
| Auth | NextAuth.js (credentials) |
| ORM | Prisma |
| Database | PostgreSQL |
| Deployment | Vercel |

---

## 🚀 Deploy to Vercel (step-by-step)

### 1. Set up a PostgreSQL database

Use one of these free options:
- **Vercel Postgres** (easiest — stays within Vercel dashboard)
- **Supabase** → supabase.com → New project → Settings → Database → Connection string
- **Neon** → neon.tech → New project → copy connection string

### 2. Push to GitHub

```bash
cd quizmaster
git init
git add .
git commit -m "Initial commit"
# Create a new repo on GitHub, then:
git remote add origin https://github.com/YOUR_USERNAME/quizmaster.git
git push -u origin main
```

### 3. Deploy on Vercel

1. Go to [vercel.com](https://vercel.com) → **New Project**
2. Import your GitHub repository
3. Set the following **Environment Variables**:

| Variable | Value |
|----------|-------|
| `DATABASE_URL` | Your PostgreSQL connection string |
| `NEXTAUTH_URL` | `https://your-app.vercel.app` (your actual Vercel URL) |
| `NEXTAUTH_SECRET` | Run `openssl rand -base64 32` and paste the output |

4. Click **Deploy**

### 4. Run database migrations

After deployment, in your terminal:

```bash
# Install dependencies locally first
npm install

# Copy the DATABASE_URL into a local .env file
cp .env.example .env
# Edit .env and fill in DATABASE_URL, NEXTAUTH_URL, NEXTAUTH_SECRET

# Push schema to the database
npx prisma db push

# Seed with sample quizzes
npm run db:seed
```

Or you can run migrations via Vercel CLI:
```bash
npx vercel env pull .env.local
npx prisma db push
npm run db:seed
```

---

## 💻 Local Development

```bash
# Install dependencies
npm install

# Set up environment
cp .env.example .env
# Fill in .env with your values

# Push schema
npx prisma db push

# Seed sample data
npm run db:seed

# Start dev server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

Demo login: `admin@quizmaster.app` / `quizmaster2024!`

---

## 📁 Project Structure

```
quizmaster/
├── app/
│   ├── page.tsx              # Homepage with featured quizzes
│   ├── login/page.tsx        # Sign in page
│   ├── register/page.tsx     # Sign up page
│   ├── dashboard/page.tsx    # User dashboard
│   ├── quiz/
│   │   ├── [id]/
│   │   │   ├── page.tsx      # Quiz detail + start screen
│   │   │   └── QuizPlayer.tsx # Interactive quiz component
│   │   ├── create/page.tsx   # Quiz creation wizard
│   │   └── join/page.tsx     # Join by invite code
│   └── api/
│       ├── auth/[...nextauth]/ # NextAuth handler
│       ├── register/          # User registration
│       ├── quizzes/           # CRUD for quizzes
│       │   └── [id]/attempt/  # Record quiz attempts
│       └── user/stats/        # User progress stats
├── components/
│   ├── Navbar.tsx
│   └── QuizCard.tsx
├── lib/
│   ├── auth.ts               # NextAuth options
│   └── prisma.ts             # Prisma client singleton
├── prisma/
│   ├── schema.prisma
│   └── seed.ts               # 50-question sample data
└── types/
    └── next-auth.d.ts
```

---

## 🔑 Environment Variables

```env
DATABASE_URL="postgresql://..."
NEXTAUTH_URL="https://your-app.vercel.app"
NEXTAUTH_SECRET="your-secret-here"
```

---

## 📝 Extending the App

Some ideas to build on top of this:

- **Quiz categories page** with filtering
- **Global leaderboard** across all quizzes
- **Quiz editing** — let authors update their quizzes
- **Timed sessions** with countdown animations
- **Social sharing** — share results on social media
- **OAuth providers** — add Google/GitHub login via NextAuth
- **Quiz images** — allow uploading cover images per quiz
- **Comments** — let users discuss quizzes
