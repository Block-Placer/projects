import { prisma } from '@/lib/prisma'
import { redirect } from 'next/navigation'

export default async function JoinByCodePage({
  searchParams,
}: {
  searchParams: { code?: string }
}) {
  const code = searchParams.code?.trim().toUpperCase()

  if (!code) redirect('/')

  const quiz = await prisma.quiz.findUnique({
    where: { inviteCode: code },
  })

  if (quiz) {
    redirect(`/quiz/${quiz.id}`)
  }

  // Not found
  return (
    <div style={{
      minHeight: '100vh', background: 'var(--ink)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '1.5rem',
    }}>
      <div className="card" style={{ padding: '2.5rem', maxWidth: '400px', width: '100%', textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🔍</div>
        <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.5rem', color: 'var(--parchment)', marginBottom: '0.5rem' }}>
          Quiz Not Found
        </h1>
        <p style={{ color: 'var(--parchment-muted)', marginBottom: '1.5rem' }}>
          No quiz found with code <span style={{ color: 'var(--gold)', fontFamily: 'JetBrains Mono, monospace' }}>{code}</span>
        </p>
        <a href="/" className="btn-primary" style={{ textDecoration: 'none', display: 'inline-flex' }}>
          ← Back to home
        </a>
      </div>
    </div>
  )
}
