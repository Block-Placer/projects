'use client'

import { useState, useEffect, useCallback } from 'react'

interface Question {
  id: string
  text: string
  options: string[]
  correctAnswer: number
  explanation: string
}

interface QuizPlayerProps {
  quiz: {
    id: string
    title: string
    timeLimit: number
    questions: Question[]
  }
}

type GameState = 'start' | 'playing' | 'reviewing' | 'finished'

export default function QuizPlayer({ quiz }: QuizPlayerProps) {
  const [state, setState] = useState<GameState>('start')
  const [current, setCurrent] = useState(0)
  const [selected, setSelected] = useState<number | null>(null)
  const [answers, setAnswers] = useState<(number | null)[]>(Array(quiz.questions.length).fill(null))
  const [showExplanation, setShowExplanation] = useState(false)
  const [timeLeft, setTimeLeft] = useState(quiz.timeLimit || 0)
  const [startTime, setStartTime] = useState<number>(0)
  const [saving, setSaving] = useState(false)
  const [finalScore, setFinalScore] = useState(0)

  const question = quiz.questions[current]
  const isAnswered = selected !== null
  const isCorrect = selected === question?.correctAnswer
  const totalQuestions = quiz.questions.length

  const finishQuiz = useCallback(async (finalAnswers: (number | null)[]) => {
    const score = finalAnswers.filter((a, i) => a === quiz.questions[i].correctAnswer).length
    const timeTaken = quiz.timeLimit > 0 ? quiz.timeLimit - timeLeft : Math.floor((Date.now() - startTime) / 1000)
    setFinalScore(score)
    setState('finished')
    setSaving(true)

    try {
      await fetch(`/api/quizzes/${quiz.id}/attempt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ score, total: totalQuestions, timeTaken }),
      })
    } catch (e) {
      console.error('Failed to save attempt', e)
    } finally {
      setSaving(false)
    }
  }, [quiz, timeLeft, startTime, totalQuestions])

  // Timer
  useEffect(() => {
    if (state !== 'playing' || quiz.timeLimit === 0) return
    if (timeLeft <= 0) {
      finishQuiz(answers)
      return
    }
    const t = setTimeout(() => setTimeLeft(tl => tl - 1), 1000)
    return () => clearTimeout(t)
  }, [state, timeLeft, quiz.timeLimit, answers, finishQuiz])

  const startQuiz = () => {
    setState('playing')
    setStartTime(Date.now())
    setTimeLeft(quiz.timeLimit || 0)
  }

  const selectAnswer = (idx: number) => {
    if (isAnswered) return
    setSelected(idx)
    const newAnswers = [...answers]
    newAnswers[current] = idx
    setAnswers(newAnswers)
    setShowExplanation(false)
  }

  const nextQuestion = () => {
    if (current + 1 >= totalQuestions) {
      finishQuiz(answers)
    } else {
      setCurrent(c => c + 1)
      setSelected(null)
      setShowExplanation(false)
    }
  }

  const restartQuiz = () => {
    setState('start')
    setCurrent(0)
    setSelected(null)
    setAnswers(Array(totalQuestions).fill(null))
    setShowExplanation(false)
    setTimeLeft(quiz.timeLimit || 0)
  }

  // START SCREEN
  if (state === 'start') {
    return (
      <div className="card" style={{ padding: '2rem', textAlign: 'center', animation: 'slideUp 0.3s ease-out' }}>
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎯</div>
        <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.5rem', color: 'var(--parchment)', marginBottom: '0.5rem' }}>
          Ready to begin?
        </h2>
        <p style={{ color: 'var(--parchment-muted)', marginBottom: '1.5rem', lineHeight: 1.6 }}>
          {totalQuestions} questions · {quiz.timeLimit > 0 ? `${Math.floor(quiz.timeLimit / 60)} minute time limit` : 'No time limit'} · Good luck!
        </p>
        <button className="btn-primary" onClick={startQuiz} style={{ padding: '0.75rem 2rem', fontSize: '1rem' }}>
          Start Quiz →
        </button>
      </div>
    )
  }

  // FINISHED SCREEN
  if (state === 'finished') {
    const pct = Math.round((finalScore / totalQuestions) * 100)
    const grade = pct >= 90 ? { label: 'Outstanding', color: 'var(--sage)', emoji: '🏆' }
                : pct >= 70 ? { label: 'Well done', color: 'var(--gold)', emoji: '⭐' }
                : pct >= 50 ? { label: 'Good effort', color: 'var(--gold-dark)', emoji: '📈' }
                : { label: 'Keep practicing', color: 'var(--crimson)', emoji: '💪' }

    return (
      <div className="card" style={{ padding: '2.5rem', animation: 'slideUp 0.3s ease-out' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{ fontSize: '3rem', marginBottom: '0.75rem' }}>{grade.emoji}</div>
          <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.75rem', color: grade.color, marginBottom: '0.25rem' }}>
            {grade.label}!
          </h2>
          <p style={{ color: 'var(--parchment-muted)' }}>Quiz complete</p>
        </div>

        {/* Score ring */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          gap: '3rem', flexWrap: 'wrap', marginBottom: '2rem',
        }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '4rem', fontWeight: 700, color: grade.color, lineHeight: 1 }}>
              {pct}%
            </div>
            <div style={{ fontSize: '0.875rem', color: 'var(--parchment-dim)', marginTop: '0.25rem' }}>
              {finalScore} / {totalQuestions} correct
            </div>
          </div>
        </div>

        {/* Review answers */}
        <div style={{ marginBottom: '2rem' }}>
          <h3 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1rem', color: 'var(--parchment)', marginBottom: '0.75rem' }}>
            Answer Review
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
            {quiz.questions.map((q, i) => {
              const userAns = answers[i]
              const correct = userAns === q.correctAnswer
              return (
                <div key={q.id} style={{
                  padding: '0.875rem 1rem',
                  background: correct ? 'rgba(107,158,122,0.08)' : 'rgba(196,103,90,0.08)',
                  border: `1px solid ${correct ? 'rgba(107,158,122,0.25)' : 'rgba(196,103,90,0.25)'}`,
                  borderRadius: '8px',
                }}>
                  <div style={{ display: 'flex', gap: '0.625rem', alignItems: 'flex-start' }}>
                    <span style={{ flexShrink: 0, fontSize: '1rem' }}>{correct ? '✅' : '❌'}</span>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontSize: '0.875rem', color: 'var(--parchment)', fontWeight: 500 }}>Q{i + 1}: {q.text}</p>
                      {!correct && (
                        <p style={{ fontSize: '0.8rem', color: 'var(--sage)', marginTop: '0.25rem' }}>
                          ✓ {q.options[q.correctAnswer]}
                        </p>
                      )}
                      {q.explanation && (
                        <p style={{ fontSize: '0.78rem', color: 'var(--parchment-dim)', marginTop: '0.25rem', fontStyle: 'italic' }}>
                          {q.explanation}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {saving && (
          <p style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--parchment-dim)', marginBottom: '1rem' }}>
            Saving your results…
          </p>
        )}

        <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center' }}>
          <button className="btn-primary" onClick={restartQuiz}>
            Try again
          </button>
          <a href="/dashboard" className="btn-secondary" style={{ textDecoration: 'none' }}>
            Back to dashboard
          </a>
        </div>
      </div>
    )
  }

  // QUIZ PLAYING
  const progress = ((current) / totalQuestions) * 100
  const timerPct = quiz.timeLimit > 0 ? (timeLeft / quiz.timeLimit) * 100 : 100
  const timerColor = timerPct > 50 ? 'var(--sage)' : timerPct > 25 ? 'var(--gold)' : 'var(--crimson)'

  return (
    <div style={{ animation: 'slideUp 0.3s ease-out' }}>
      {/* Progress bar */}
      <div style={{ marginBottom: '1.25rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
          <span style={{ fontSize: '0.85rem', color: 'var(--parchment-dim)' }}>
            Question {current + 1} of {totalQuestions}
          </span>
          {quiz.timeLimit > 0 && (
            <span style={{ fontSize: '0.875rem', fontFamily: 'JetBrains Mono, monospace', color: timerColor, fontWeight: 500 }}>
              ⏱ {Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}
            </span>
          )}
        </div>
        <div style={{ height: '4px', background: 'var(--ink-50)', borderRadius: '2px', overflow: 'hidden' }}>
          <div style={{
            height: '100%', background: 'var(--gold)',
            width: `${((current + (isAnswered ? 1 : 0)) / totalQuestions) * 100}%`,
            transition: 'width 0.3s ease',
            borderRadius: '2px',
          }} />
        </div>
      </div>

      {/* Question card */}
      <div className="card" style={{ padding: '2rem' }}>
        <h2 style={{
          fontFamily: 'Playfair Display, serif',
          fontSize: '1.25rem',
          color: 'var(--parchment)',
          lineHeight: 1.5,
          marginBottom: '1.5rem',
        }}>
          {question.text}
        </h2>

        {/* Options */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.625rem' }}>
          {question.options.map((opt, idx) => {
            let bg = 'var(--ink-50)'
            let border = 'rgba(212,165,116,0.15)'
            let color = 'var(--parchment)'

            if (isAnswered) {
              if (idx === question.correctAnswer) {
                bg = 'rgba(107,158,122,0.15)'
                border = 'rgba(107,158,122,0.5)'
                color = 'var(--sage)'
              } else if (idx === selected && idx !== question.correctAnswer) {
                bg = 'rgba(196,103,90,0.15)'
                border = 'rgba(196,103,90,0.5)'
                color = 'var(--crimson)'
              } else {
                color = 'var(--parchment-dim)'
              }
            } else if (selected === idx) {
              border = 'var(--gold)'
            }

            return (
              <button
                key={idx}
                onClick={() => selectAnswer(idx)}
                disabled={isAnswered}
                style={{
                  background: bg,
                  border: `1px solid ${border}`,
                  borderRadius: '8px',
                  padding: '0.875rem 1.125rem',
                  textAlign: 'left',
                  color,
                  cursor: isAnswered ? 'default' : 'pointer',
                  transition: 'all 0.15s ease',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                  fontSize: '0.9375rem',
                  fontFamily: 'DM Sans, sans-serif',
                }}
                onMouseEnter={e => {
                  if (!isAnswered) {
                    e.currentTarget.style.borderColor = 'rgba(212,165,116,0.5)'
                    e.currentTarget.style.background = 'rgba(212,165,116,0.06)'
                  }
                }}
                onMouseLeave={e => {
                  if (!isAnswered) {
                    e.currentTarget.style.borderColor = 'rgba(212,165,116,0.15)'
                    e.currentTarget.style.background = 'var(--ink-50)'
                  }
                }}
              >
                <span style={{
                  width: '28px', height: '28px', borderRadius: '6px',
                  background: 'rgba(212,165,116,0.1)',
                  border: '1px solid rgba(212,165,116,0.2)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '0.8rem', fontWeight: 600, flexShrink: 0,
                  color: 'var(--gold)',
                }}>
                  {String.fromCharCode(65 + idx)}
                </span>
                {opt}
                {isAnswered && idx === question.correctAnswer && (
                  <span style={{ marginLeft: 'auto' }}>✓</span>
                )}
                {isAnswered && idx === selected && idx !== question.correctAnswer && (
                  <span style={{ marginLeft: 'auto' }}>✗</span>
                )}
              </button>
            )
          })}
        </div>

        {/* Explanation */}
        {isAnswered && question.explanation && (
          <div style={{
            marginTop: '1.25rem',
            padding: '0.875rem 1rem',
            background: 'rgba(212,165,116,0.06)',
            border: '1px solid rgba(212,165,116,0.15)',
            borderRadius: '8px',
            animation: 'fadeIn 0.3s ease-out',
          }}>
            <p style={{ fontSize: '0.875rem', color: 'var(--parchment-muted)', lineHeight: 1.6 }}>
              <span style={{ color: 'var(--gold)', fontWeight: 600, marginRight: '0.375rem' }}>💡</span>
              {question.explanation}
            </p>
          </div>
        )}

        {/* Next button */}
        {isAnswered && (
          <div style={{ marginTop: '1.5rem', display: 'flex', justifyContent: 'flex-end', animation: 'fadeIn 0.25s ease-out' }}>
            <button className="btn-primary" onClick={nextQuestion} style={{ padding: '0.625rem 1.5rem' }}>
              {current + 1 >= totalQuestions ? 'See results →' : 'Next question →'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
